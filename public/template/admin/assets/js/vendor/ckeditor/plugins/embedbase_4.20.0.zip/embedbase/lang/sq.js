/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'sq', {
	pathName: 'Objekt mediatik',
	title: 'Media Bashkangjitur',
	button: 'Shto Lidhje Mediatike',
	unsupportedUrlGiven: 'URL e shkruar nuk është e mbështetur.',
	unsupportedUrl: 'URL {url} nuk është e mbështetur nga Media Embed.',
	fetchingFailedGiven: 'Dështoi tërheqja e përmbajtjes nga URL e dhënë.',
	fetchingFailed: 'Dështoi tërheqja e përmbajtjes nga  {url}.',
	fetchingOne: 'Përgjigja e tërheqjes së oEmbed...',
	fetchingMany: 'Përgjigja e tërheqjes së oEmbed, janë realizuar {current} nga {max}...'
} );

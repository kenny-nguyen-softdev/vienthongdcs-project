/*
 Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'uk', {
	embeddingInProgress: 'Намагаюсь вбудувати вставлене URL посилання...',
	embeddingFailed: 'Це URl посилання не може бути автоматично вбудовано.'
} );

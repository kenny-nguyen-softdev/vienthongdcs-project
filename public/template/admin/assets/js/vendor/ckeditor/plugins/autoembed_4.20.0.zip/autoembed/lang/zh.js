/*
 Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */
CKEDITOR.plugins.setLang( 'autoembed', 'zh', {
	embeddingInProgress: '正在嘗試嵌入已貼上的 URL...',
	embeddingFailed: '這個 URL 無法被自動嵌入。'
} );
